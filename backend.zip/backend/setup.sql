CREATE DATABASE IF NOT EXISTS `ide`;
USE `ide`;

# Definiciones de tablas y columnas
CREATE TABLE `usuarios` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
	`usuario` varchar(255) DEFAULT NULL,
	`contrasena` varchar(255) DEFAULT NULL,
	`nombre` varchar(255) DEFAULT NULL,
	PRIMARY KEY (`id`)
)

# Seleccionar el motor
ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

# Para las tablas que he definido,  grabar esta informacion
#INSERT INTO `usuarios` (`id`, `usuario`,`contrasena`,`nombre`)
#VALUES
