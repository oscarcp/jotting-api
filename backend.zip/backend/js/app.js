var map; //complex object of type OpenLayers.Map

function init() {
    map = new OpenLayers.Map ("mapaosm", {
        controls:[
            new OpenLayers.Control.Navigation(),
            new OpenLayers.Control.PanZoomBar(),
            new OpenLayers.Control.LayerSwitcher()],
        maxExtent: new OpenLayers.Bounds(-20037508.34,-20037508.34,20037508.34,20037508.34),
        maxResolution: 156543.0399,
        numZoomLevels: 19,
        units: 'm',
        projection: new OpenLayers.Projection("EPSG:900913"),
        displayProjection: new OpenLayers.Projection("EPSG:4326")
    } );

    // Define the map layer
    // Here we use a predefined layer that will be kept up to date with URL changes
    layerMapnik = new OpenLayers.Layer.OSM.Mapnik("Mapnik");
    map.addLayer(layerMapnik);

    // Add the Layer with the GPX Track
    var lgpx = new OpenLayers.Layer.Vector("rutapontecaldelas", {
        strategies: [new OpenLayers.Strategy.Fixed()],
        protocol: new OpenLayers.Protocol.HTTP({
            url: "mapas/rutapontecaldelas.gpx",
            format: new OpenLayers.Format.GPX()
        }),
        style: {strokeColor: "blue", strokeWidth: 10, strokeOpacity: 0.8},
        projection: new OpenLayers.Projection("EPSG:4326")
    });
    map.addLayer(lgpx);

    // Start position for the map (hardcoded here for simplicity,
    // but maybe you want to get this from the URL params)
    var lat=42.3885;
    var lon=-8.4833;
    var zoom=16;
    var lonLat = new OpenLayers.LonLat(lon, lat).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject());
    map.setCenter(lonLat, zoom);
}

function initmap() {
    // The location of Uluru
    //var uluru = {lat: 42.391157, lng: -8.491953};
    // The map, centered at Uluru
    //var map = new google.maps.Map(
      //document.getElementById('mapagmaps'), {zoom: 17, center: uluru});
    // The marker, positioned at Uluru
    //var marker = new google.maps.Marker({position: uluru, map: map});
    var map = new google.maps.Map(document.getElementById('mapagmaps'), {
       zoom: 17,
       center: {lat: 42.391157, lng: -8.491953}
    });

    var ctaLayer = new google.maps.KmlLayer({
        url: 'https://raw.githubusercontent.com/oscarcp/jotting-api/master/rutapontecaldelas.kml',
        map: map
    });
}


$(document).ready(function(){
});

