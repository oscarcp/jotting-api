<?php
require_once "sesion.php";
require_once "auth.php";
$sesion = new Sesion();
$usuario = new UsuarioBD();
$usuario->login();
?>

<!DOCTYPE html>
	<head>
		<title>Comprobando el usuario</title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width,initial-scale=1">
	</head>
	<body>
		<div class="container">
			<h1>Acceso permitido</h1>
			<div class="col-md-12 well">
				Usuario: <?=$_SESSION["usuario"]?>
			</div>
			<div class="col-md-12 well">
				Contrasena: <?=$_SESSION["contrasena"]?>
			</div>
			<div class="col-md-12 well">
				Nombre: <?=$_SESSION["nombre"]?>
			</div>
			<div class="col-md-12 well">
				<div class="span12">
					<a href='logout.php'>Salir</a>
				</div>
			</div>
		</div>
	</body>
</html>
