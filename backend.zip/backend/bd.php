<?php
	class Servidor_Base_Datos {
		private $ini_array;
        private $servidor;
        private $usuario;
        private $contrasena;
        private $nombredb;

		function __construct() {
			$ini_array = parse_ini_file("config.ini");
			$this->servidor = $ini_array["hostmysql"];
			$this->usuario = $ini_array["usuario"];
			$this->contrasena = $ini_array["contrasena"];
			$this->nombredb = $ini_array["nombre"];
			$this->conectar_base_datos();
		}

		private function conectar_base_datos()  {
			$this->descriptor = mysqli_connect($this->servidor,$this->usuario, $this->contrasena, $this->nombredb);
		}

		public function consulta($consulta) {
			$this->resultado = mysqli_query ( $this->descriptor, $consulta);
		}

		public function extraer_registro() {
			if ( $fila = mysqli_fetch_array ( $this->resultado, MYSQLI_ASSOC)) {
			return $fila;
			} else {
			return false;
			}
		}

		public function extraer_registros() {
			$registros = array();
			while ($fila = $this->resultado->fetch_array( MYSQLI_ASSOC)){
				$registros[] = $fila;
			}
		return $registros;
		}
	}


?>
