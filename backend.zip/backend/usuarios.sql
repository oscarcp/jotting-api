USE ide;
INSERT INTO usuarios (usuario,contrasena,nombre)
VALUES('nurials', '202cb962ac59075b964b07152d234b70', 'Nuria');
INSERT INTO usuarios (usuario,contrasena,nombre)
VALUES('oscarcp', '250cf8b51c773f3f8dc8b4be867a9a02', 'Oscar');
INSERT INTO usuarios (usuario,contrasena,nombre)
VALUES('nuria', '1b8bbe06f76b270d848bda6198497dfe', 'Administrador');
