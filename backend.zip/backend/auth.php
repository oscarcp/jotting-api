<?php
    require_once "sesion.php";
    require_once "bd.php";

    class UsuarioBD {
        private $users_array;

        function __construct() {
            $bd = new Servidor_Base_Datos();
            $bd->consulta("select * from usuarios");
            $this->users_array = $bd->extraer_registros();
        }

        public function existeUsuario($username) {
            foreach ($this->users_array as $registro) {
                if ($registro["usuario"] == $username){
                    return true;
                }
            }
            return false;
        }

        public function comprobarClave($username, $clave) {
            foreach ($this->users_array as $registro) {
                if ($registro["usuario"] == $username && md5($registro["contrasena"] == $clave)){
                    return true;
                }
            }
            return false;
        }

        private function getUsuario($username) {
            foreach ($this->users_array as $registro) {
                if ($registro["usuario"] == $username){
                    return $registro;
                }
            }
            return array();
        }

        public function login(){
            if (isset($_POST["usuario"]) && isset($_POST["contrasena"])) {
                $username = $_POST["usuario"];
                $password = $_POST["contrasena"];

                if ( $this->existeUsuario($username) == true && $this->comprobarClave($username, $password) == true){
                    $_SESSION = $this->getUsuario($username);
                } else {
                    header("Location:clientes.php");
                }
            } else {
                header("Location:login.html");
            }
        }

        public function logout() {
            $sesion = new Sesion();
            $sesion->terminarSesion();
            header("Location:login.html");
        }
    }
?>
