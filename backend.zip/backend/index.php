<?php
    require("utils.php");
    require("bd.php");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Explority</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <meta name="viewport" content="initial-scale=1">
    <script src="js/jquery-3.3.1.min.js" type="text/javascript" charset="utf-8" async defer></script>
    <script src="js/app.js" type="text/javascript" charset="utf-8" async defer></script>
</head>
<body>
    <nav class="cabecera">
        <div class="logo"></div>
        <div class="menu">
            <ul>
                <li> <a href="index.php">Inicio </a></li>
                <li> <a href="nosotros.html">Nosotros </a></li>
                <li> <a href="clientes.php">Clientes</a></li>
                <li> <a href="contacto.html">Contacto </a></li>
                <li> <a href="osm.php">Openstreetmap </a></li>
            </ul>
        </div>
    </nav>
    <div class="hero">
        <div class="info-hero">
            <h3> Escaneado 3D </h3>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam felis purus, condimentum nec augue eget, placerat volutpat quam. Sed id nibh sit amet dolor porta finibus ut eget risus. </p>
        </div>
    </div>

    <div class="contenedor">
        <section>
            <article>
                <h3> Tecnología 3D</h3>
                <img class="imagen-articulo" src="http://www.placehold.it/670x400" />
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam felis purus, condimentum nec augue eget, placerat volutpat quam. Sed id nibh sit amet dolor porta finibus ut eget risus. Nulla eleifend est erat, eu maximus ex vestibulum a. Nam sit amet mauris nec lacus lacinia pulvinar et id quam. Nulla fermentum sapien sed nunc porta aliquam. Maecenas rutrum risus in ante bibendum, sit amet porttitor mauris tempus. Morbi egestas commodo mauris ac mollis. Integer et lorem et lacus viverra tincidunt eget ut felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec ornare mi quis posuere cursus. Fusce hendrerit imperdiet leo, eu viverra turpis tincidunt vel. Vestibulum in euismod erat, et venenatis lectus. </p>
            </article>
        </section>
    </div>
    <footer>
        <span class="columna">
            <img src="img/logo1.png" class="logofooter"/>
        </span>
        <span class="columna">
            <ul>
                <li> <a href="index.php">Inicio </a></li>
                <li> <a href="nosotros.html">Nosotros </a></li>
                <li> <a href="clientes.php">Clientes</a></li>
                <li> <a href="contacto.html">Contacto </a></li>
                <li> <a href="osm.php">Openstreetmap </a></li>
            </ul>
        </span>
        <span class="columna">
           <h3> Contacto </h3> <br>
                Calle cruz roja <br>
                Nª8 Bajo <br>
                CP:36002 <br>
                explority@gmail.com

        </span>
        <span class="columna">
            <img src="img/Faro-logo.png"/>
            <img src="img/leica.png"/>
            <img src="img/salamanca.png"/>

            Derechos reservados       Página IDE     2018 &#174
        </span>
    </footer>
</body>
</html>
