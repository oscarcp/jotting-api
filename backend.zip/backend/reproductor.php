<?php
	class reproductor(){
		private $botones;
		private $imagen;
		private $estado;

		function__construct(){
			$ini_array = parse_ini_file("config2.ini");
			$this->calidad= $ini_array["calidad"];
			$this->volumen= $ini_array["pausa"];
			$this->abrir();
		}

		private function abrir()  {
			$this->descriptor = mysqli_connect($this->botones,$this->imagen, $this->estado);
		}

		public function play($play) {
			$this->inicio = mysqli_query ( $this-> descriptor, $play);
		}
		public function pausa($pausa) {
			$this->pausa = mysqli_query ( $this-> descriptor, $pausa);
		}
		public function aleatorio($aleatorio) {
			$this->aleaotorio = mysqli_query ( $this-> descriptor, $aleatorio);
		}
	}
?>
