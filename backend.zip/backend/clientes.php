<?php
    require("utils.php");
    require("auth.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Explority</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <meta name="viewport" content="initial-scale=1">
    <script src="js/jquery-3.3.1.min.js" type="text/javascript" charset="utf-8" async defer></script>
</head>
<body>
    <nav class="cabecera">
        <div class="logo"></div>
        <div class="menu">
            <ul>
                <li> <a href="index.php">Inicio </a></li>
                <li> <a href="nosotros.html">Nosotros </a></li>
                <li> <a href="clientes.php">Clientes</a></li>
                <li> <a href="contacto.html">Contacto </a></li>
                <li> <a href="osm.php">Openstreetmap </a></li>
            </ul>
        </div>
    </nav>
    <div class="contenedor">
        <section>
            <article>
             <h3> Iniciar sesión </h3>
                 <span class="contactoformulario">
                    <form role="form"id="miformulario" action="comprobarUsuario.php" method="post">
                        <div class="form_group">
                            <label for="username"> Usuario:</label>
                            <input type="text" name="usuario" placeholder="Escriba el nombre de usuario" required="true"/>
                        <div class="form_group">
                            <label> Contraseña: </label>
                            <input type="text" name="contrasena" placeholder="Escriba el nombre de usuario" required="true"/>
                        <div class="form_group">
                            <input type="submit" value="Submit">
                    </form>
                </span>
            </article>
        </section>

    </div>
    <footer>
        <span class="columna">
            <img src="img/logo1.png" class="logofooter"/>
        </span>
        <span class="columna">
            <ul>
                <li> <a href="index.php">Inicio </a></li>
                <li> <a href="nosotros.html">Nosotros </a></li>
                <li> <a href="clientes.php">Clientes</a></li>
                <li> <a href="contacto.html">Contacto </a></li>
                <li> <a href="osm.php">Openstreetmap </a></li>
            </ul>
        </span>
        <span class="columna">
           <h3> Contacto </h3> <br>
                Calle cruz roja <br>
                Nª8 Bajo <br>
                CP:36002 <br>
                explority@gmail.com

        </span>
        <span class="columna">
            <img src="img/Faro-logo.png"/>
            <img src="img/leica.png"/>
            <img src="img/salamanca.png"/>

            Derechos reservados       Página IDE     2018 &#174
        </span>
    </footer>
</body>
</html>
